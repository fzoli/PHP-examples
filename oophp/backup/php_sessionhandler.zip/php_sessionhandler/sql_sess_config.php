<?php
$dbhost = 'fzoli.dyndns.org';
$dbuser = 'sessionhandler';
$dbpass = 'teszt';
$dbport = '3306';
//$dbhost = 'localhost';
//$dbuser = 'root';
//$dbpass = 'password';
//$dbsock = '/var/run/mysqld.sock';
?>
